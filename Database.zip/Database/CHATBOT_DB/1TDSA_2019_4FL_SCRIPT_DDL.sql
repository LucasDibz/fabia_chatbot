-- Gerado por Oracle SQL Developer Data Modeler 19.2.0.182.1216
--   em:        2019-10-05 14:05:08 BRT
--   site:      Oracle Database 11g
--   tipo:      Oracle Database 11g

/*
Componentes do Grupo:
RM 83931	- Leonardo Santos
RM 82270	- Luiz Henrique
RM 82029	- Lucas Ferreira Dib
RM 83821	- F�bio Monteiro

/*
DROP TABLE t_chatbot_aluno CASCADE CONSTRAINTS;
DROP TABLE t_chatbot_conteudo CASCADE CONSTRAINTS;
DROP TABLE t_chatbot_disciplina CASCADE CONSTRAINTS;
DROP TABLE t_chatbot_matricula CASCADE CONSTRAINTS;
DROP TABLE t_chatbot_progressao CASCADE CONSTRAINTS;
*/

CREATE TABLE t_chatbot_aluno (
    nr_rm         NUMBER(5) NOT NULL,
    nm_aluno      VARCHAR2(50) NOT NULL,
    ds_email      VARCHAR2(70) NOT NULL,
    sn_aluno      VARCHAR2(20) NOT NULL,
    nr_telefone   NUMBER(11),
    nr_cpf        NUMBER(11) NOT NULL,
    nr_cep        NUMBER(8) NOT NULL
);

ALTER TABLE t_chatbot_aluno ADD CONSTRAINT pk_aluno PRIMARY KEY ( nr_rm );

CREATE TABLE t_chatbot_conteudo (
    cd_conteudo     NUMBER(3) NOT NULL,
    cd_disciplina   NUMBER(2) NOT NULL,
    ds_titulo       VARCHAR2(80) NOT NULL,
    lc_conteudo     VARCHAR2(50) NOT NULL
);

ALTER TABLE t_chatbot_conteudo ADD CONSTRAINT pk_conteudo PRIMARY KEY ( cd_conteudo );

CREATE TABLE t_chatbot_disciplina (
    cd_disciplina   NUMBER(2) NOT NULL,
    nm_disciplina   VARCHAR2(30) NOT NULL,
    st_status       NUMBER(1) NOT NULL
);

ALTER TABLE t_chatbot_disciplina ADD CONSTRAINT pk_disciplina PRIMARY KEY ( cd_disciplina );

ALTER TABLE t_chatbot_disciplina ADD CONSTRAINT un_nm_disciplina UNIQUE ( nm_disciplina );

CREATE TABLE t_chatbot_matricula (
    nr_rm           NUMBER(5) NOT NULL,
    cd_disciplina   NUMBER(2) NOT NULL,
    dt_inicio       DATE NOT NULL,
    dt_termino      DATE
);

ALTER TABLE t_chatbot_matricula ADD CONSTRAINT ck_matric_data CHECK ( dt_termino > dt_inicio );

ALTER TABLE t_chatbot_matricula ADD CONSTRAINT pk_matricula PRIMARY KEY ( nr_rm,
                                                                          cd_disciplina );
CREATE TABLE t_chatbot_progressao (
    cd_conteudo     NUMBER(3) NOT NULL,
    nr_rm           NUMBER(5) NOT NULL,
    cd_disciplina   NUMBER(2) NOT NULL,
    st_status       NUMBER(1) NOT NULL,
    st_progressao   NUMBER(3) NOT NULL
);

ALTER TABLE t_chatbot_progressao
    ADD CONSTRAINT pk_progressao PRIMARY KEY ( cd_conteudo,
                                               nr_rm,
                                               cd_disciplina );

ALTER TABLE t_chatbot_conteudo
    ADD CONSTRAINT fk_conteudo_disc FOREIGN KEY ( cd_disciplina )
        REFERENCES t_chatbot_disciplina ( cd_disciplina );

ALTER TABLE t_chatbot_matricula
    ADD CONSTRAINT fk_matric_aluno FOREIGN KEY ( nr_rm )
        REFERENCES t_chatbot_aluno ( nr_rm );

ALTER TABLE t_chatbot_matricula
    ADD CONSTRAINT fk_matric_disc FOREIGN KEY ( cd_disciplina )
        REFERENCES t_chatbot_disciplina ( cd_disciplina );

ALTER TABLE t_chatbot_progressao
    ADD CONSTRAINT fk_prog_cont FOREIGN KEY ( cd_conteudo )
        REFERENCES t_chatbot_conteudo ( cd_conteudo );

ALTER TABLE t_chatbot_progressao
    ADD CONSTRAINT fk_prog_matric FOREIGN KEY ( nr_rm,
                                                cd_disciplina )
        REFERENCES t_chatbot_matricula ( nr_rm,
                                         cd_disciplina );


-- Relat�rio do Resumo do Oracle SQL Developer Data Modeler: 
-- 
-- CREATE TABLE                             5
-- CREATE INDEX                             0
-- ALTER TABLE                             12
-- CREATE VIEW                              0
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   0
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          0
-- CREATE MATERIALIZED VIEW                 0
-- CREATE MATERIALIZED VIEW LOG             0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
--
-- ORDS DROP SCHEMA                         0
-- ORDS ENABLE SCHEMA                       0
-- ORDS ENABLE OBJECT                       0
--
-- ERRORS                                   0
-- WARNINGS                                 0
