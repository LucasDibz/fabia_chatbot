//	$(document).ready(function() {
//	function idemail(email) {
//		var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
//		return regex.test(email);
//
//	  }

   
//	$('#idconfirm').blur(function() {
   //     if ($('#idsenha').val() != $('#idconfirm').val()) {
		
//			$(this).css('background-color','red')
//		}
//	}) 

	//$('#idconfirm').blur(function(idemail) {
      // if (!idemail){
		//   alert("foi?")
	  // }
//	})
//})
